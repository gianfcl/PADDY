$( document ).ready(function() {
  $('#fecha_busc').daterangepicker({
    singleDatePicker: true,
    format: 'YYYY-MM-DD',
    calender_style: "picker_4"
    }, 
    function(start, end, label) {}
  );
  $.validator.addMethod("formespn",
    function(value, element) {
      if(value.trim().length)
        return /^(0?[1-9]|[12]\d|3[01])[\.\/\-](0?[1-9]|1[012])[\.\/\-]([12]\d)?(\d\d)$/.test( value );
      else
        return false;
  }, "");


  $("#user").autocomplete({
    type:'POST',
    serviceUrl: $('base').attr('href')+"usuarios/get_usuario",
    onSelect: function (suggestion) 
    {
      $('#id_usuario').val(suggestion.id_usuario);
    }
  });

});

$(document).on('focusout', '#user', function (e) {
  var user = $('#user').val();
  var id = parseInt($('#id_usuario').val());
  id = (id >0) ? (id) : (0);

  if(user.trim().length && id>0) {}
  else
  {
    $('#user').val('');
    $('#id_usuario').val('');
  }
});

$(document).on('click', '#datatable-buttons .limpiarfiltro', function (e) {
  var id = $(this).parents('tr').attr('id');
  $('#'+id).find('input[type=text]').val('');
  $('#'+id).find('select').val('');
  buscar_documentos(0);
});

$(document).on('click', '#datatable_paginate li.paginate_button', function (e) {  
  var page = $(this).find('a').attr('tabindex');
  buscar_documentos(page);
});

$(document).on('click', '#datatable_paginate a.paginate_button', function (e) {
  var page = $(this).attr('tabindex');
  buscar_documentos(page);
});

$(document).on('click', '#datatable-buttons .buscar', function (e) {
  var page = 0;
  buscar_documentos(page);
});

function buscar_documentos(page)
{
  var codigo_busc = $('#codigo_busc').val();
  var serie_busc = $('#serie_busc').val();
  var numero_busc = $('#numero_busc').val();
  var tipodoc_busc = $('#tipodoc_busc').val();
  var fecha_busc = $('#fecha_busc').val();
  var ruc_dni = $('#ruc_dni').val();
  var nombres_com = $('#nombres_com').val();
  var id = parseInt($('#id_usuario').val());
  id = (id >0) ? (id) : (0);
  var estado = parseInt($('#estado').val());
  estado = (estado >0) ? (estado) : (0);
  //var estado_busc = $('#estado_busc').val();

  var temp = "page="+page+'&id_tipomovimiento=1';
  if(codigo_busc.trim().length)
  {
    temp=temp+'&codigo_busc='+codigo_busc;
  }
  if(numero_busc.trim().length)
  {
    temp=temp+'&numero_busc='+numero_busc;
  }
  if(serie_busc.trim().length)
  {
    temp=temp+'&serie_busc='+serie_busc;
  }
  if(tipodoc_busc.trim().length)
  {
    temp=temp+'&tipodoc_busc='+tipodoc_busc;
  }  
  if(fecha_busc.trim().length)
  {
    temp=temp+'&fecha_busc='+fecha_busc;
  }
  if(ruc_dni.trim().length)
  {
    temp=temp+'&ruc_dni='+ruc_dni;
  }
  if(nombres_com.trim().length)
  {
    temp=temp+'&nombres_com='+nombres_com;
  }
  if(id>0)
  {
    temp=temp+'&id_user='+id;
  }
  if(estado>0)
  {
    temp=temp+'&estado='+estado;
  }

  $.ajax({
    url: $('base').attr('href') + 'ingresoxcompra/buscar_documentos',
    type: 'POST',
    data: temp,
    dataType: "json",
    beforeSend: function() {
      $.LoadingOverlay("show", {image : "", fontawesome : "fa fa-spinner fa-spin"});
    },
    success: function(response) {
      if (response.code==1) {
        $('#datatable-buttons tbody#bodyindex').html(response.data.rta);
        $('#paginacion_data').html(response.data.paginacion);
        $('#fecha_busc').daterangepicker({
          singleDatePicker: true,
          format: 'YYYY-MM-DD',
          calender_style: "picker_4"
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
      }
    },
    complete: function() {
      $.LoadingOverlay("hide");     
    }
  });
}